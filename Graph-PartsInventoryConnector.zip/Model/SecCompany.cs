﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

using Markdig;
using Microsoft.Graph.Models.ExternalConnectors;
using YamlDotNet.Serialization;



namespace Graph_PartsInventoryConnector.Model
{
    public interface IMarkdown
    {
        string? Markdown { get; set; }
    }
    public class SecCompany
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Cik { get; set; }

        [Required]
        public string Name { get; set; }

        public string Ticker { get; set; }

        public string Description { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
    public class SecFiling
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public DateTime FilingDate { get; set; }

        [Required]
        public DateTime ReportDate { get; set; }

        [Required]
        [MaxLength(10)]
        public string CompanyTicker { get; set; }

        [Required]
        [MaxLength(255)]
        public string CompanyName { get; set; }

        [Required]
        [MaxLength(10)]
        public string Cik { get; set; } // Foreign Key to SecCompany

        [Required]
        [MaxLength(10)]
        public string FormType { get; set; }

        [Required]
        [MaxLength(20)]
        public string AccessionNumber { get; set; }

        [Required]
        public string FilingUrl { get; set; }

        [MaxLength(15)]
        public string FileNumber { get; set; }

        [MaxLength(15)]
        public string FilmNumber { get; set; }

        public bool IsSynced { get; set; } = false;

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        //public SecFiling(DateTime FilingDate, string CompanyName, string Cik, string FormType, string AccessionNumber, string FilingUrl)
        //{
        //    FilingDate = FilingDate;
        //    CompanyName = CompanyName;
        //    Cik = Cik;
        //    FormType = FormType;
        //    AccessionNumber = AccessionNumber;
        //    FilingUrl = FilingUrl;          
        //}

    }

    class DocsFiling : IMarkdown
    {
        [YamlMember(Alias = "title")]
        public string? Title { get; set; }
        [YamlMember(Alias = "description")]
        public string? Description { get; set; }
        public string? Markdown { get; set; }
        public string? Content { get; set; }
        public DateTime FilingDate { get; set; }
        public DateTime ReportDate { get; set; }
        public string CompanyTicker { get; set; }
        public string CompanyName { get; set; }
        public string FileNumber { get; set; }
        public string FilmNumber { get; set; }
        public string Cik { get; set; } // Foreign Key to SecCompany
        public string FormType { get; set; }
        public string AccessionNumber { get; set; }
        public string FilingUrl { get; set; }
       
    }
}
