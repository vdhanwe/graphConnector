﻿using System.Text.Json;
using Graph_PartsInventoryConnector;
using Graph_PartsInventoryConnector.Data;
using Graph_PartsInventoryConnector.Graph;
using Microsoft.EntityFrameworkCore;
using Microsoft.Graph;
using Microsoft.Graph.Models.ExternalConnectors;
using Microsoft.Graph.Models.ODataErrors;
using Graph_PartsInventoryConnector;
using Graph_PartsInventoryConnector.Data;
using Graph_PartsInventoryConnector.Graph;
using Graph_PartsInventoryConnector.Model;
using System.Linq;
using Microsoft.Graph.Models;
using static Microsoft.Graph.Constants;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;
using Markdig;



Console.WriteLine("Parts Inventory Search Connector\n");

var settings = Settings.LoadSettings();

// Initialize Graph
InitializeGraph(settings);
var filingDocuments = new List<SecFiling>();
ExternalConnection? currentConnection = null;
int choice = -1;

while (choice != 0)
{
    Console.WriteLine($"Current connection: {(currentConnection == null ? "NONE" : currentConnection.Name)}\n");
    Console.WriteLine("Please choose one of the following options:");
    Console.WriteLine("0. Exit");
    Console.WriteLine("1. Create a connection");
    Console.WriteLine("2. Select an existing connection");
    Console.WriteLine("3. Delete current connection");
    Console.WriteLine("4. Register schema for current connection");
    Console.WriteLine("5. View schema for current connection");
    Console.WriteLine("6. Push updated items to current connection");
    Console.WriteLine("7. Push ALL items to current connection");
    Console.WriteLine("8. Load data to SQL Table");
    Console.Write("Selection: ");

    try
    {
        choice = int.Parse(Console.ReadLine() ?? string.Empty);
    }
    catch (FormatException)
    {
        // Set to invalid value
        choice = -1;
    }

    switch (choice)
    {
        case 0:
            // Exit the program
            Console.WriteLine("Goodbye...");
            break;
        case 1:
            currentConnection = await CreateConnectionAsync();
            break;
        case 2:
            currentConnection = await SelectExistingConnectionAsync();
            break;
        case 3:
            await DeleteCurrentConnectionAsync(currentConnection);
            currentConnection = null;
            break;
        case 4:
            await RegisterSchemaAsync();
            break;
        case 5:
            await GetSchemaAsync();
            break;
        case 6:
            await UpdateItemsFromDatabaseAsync(true, settings.TenantId);
            break;
        case 7:
            await UpdateItemsFromDatabaseAsync(false, settings.TenantId);
            break;
        case 8:
            await LoadDataToSQL();
            break;
        default:
            Console.WriteLine("Invalid choice! Please try again.");
            break;
    }
}

static string? PromptForInput(string prompt, bool valueRequired)
{
    string? response;

    do
    {
        Console.WriteLine($"{prompt}:");
        response = Console.ReadLine();
        if (valueRequired && string.IsNullOrEmpty(response))
        {
            Console.WriteLine("You must provide a value");
        }
    } while (valueRequired && string.IsNullOrEmpty(response));

    return response;
}

static DateTime GetLastUploadTime()
{
    if (File.Exists("lastuploadtime.bin"))
    {
        return DateTime.Parse(
            File.ReadAllText("lastuploadtime.bin")).ToUniversalTime();
    }

    return DateTime.MinValue;
}

static void SaveLastUploadTime(DateTime uploadTime)
{
    File.WriteAllText("lastuploadtime.bin", uploadTime.ToString("u"));
}

void InitializeGraph(Settings settings)
{
    try
    {
        GraphHelper.Initialize(settings);
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Error initializing Graph: {ex.Message}");
    }
}

async Task<ExternalConnection?> CreateConnectionAsync()
{
    
    var connectionId = PromptForInput(
        "Enter a unique ID for the new connection (3-32 characters)", true) ?? "ConnectionId";
    var connectionName = PromptForInput(
        "Enter a name for the new connection", true) ?? "ConnectionName";
    var connectionDescription = PromptForInput(
        "Enter a description for the new connection", false);

    try
    {
        // Create the connection
        var connection = await GraphHelper.CreateConnectionAsync(
            connectionId, connectionName, connectionDescription);
        Console.WriteLine($"New connection created - Name: {connection?.Name}, Id: {connection?.Id}");
        return connection;
    }
    catch (ODataError odataError)
    {
        Console.WriteLine($"Error creating connection: {odataError.ResponseStatusCode}: {odataError.Error?.Code} {odataError.Error?.Message}");
        return null;
    }
}

async Task<ExternalConnection?> SelectExistingConnectionAsync()
{
    // TODO
    Console.WriteLine("Getting existing connections...");
    try
    {
        var response = await GraphHelper.GetExistingConnectionsAsync();
        var connections = response?.Value ?? new List<ExternalConnection>();
        if (connections.Count <= 0)
        {
            Console.WriteLine("No connections exist. Please create a new connection");
            return null;
        }

        // Display connections
        Console.WriteLine("Choose one of the following connections:");
        var menuNumber = 1;
        foreach (var connection in connections)
        {
            Console.WriteLine($"{menuNumber++}. {connection.Name}");
        }

        ExternalConnection? selection = null;

        do
        {
            try
            {
                Console.Write("Selection: ");
                var choice = int.Parse(Console.ReadLine() ?? string.Empty);
                if (choice > 0 && choice <= connections.Count)
                {
                    selection = connections[choice - 1];
                }
                else
                {
                    Console.WriteLine("Invalid choice.");
                }
            }
            catch (FormatException)
            {
                Console.WriteLine("Invalid choice.");
            }
        } while (selection == null);

        return selection;
    }
    catch (ODataError odataError)
    {
        Console.WriteLine($"Error getting connections: {odataError.ResponseStatusCode}: {odataError.Error?.Code} {odataError.Error?.Message}");
        return null;
    }
}

async Task DeleteCurrentConnectionAsync(ExternalConnection? connection)
{
    if (connection == null)
    {
        Console.WriteLine(
            "No connection selected. Please create a new connection or select an existing connection.");
        return;
    }

    try
    {
        await GraphHelper.DeleteConnectionAsync(connection.Id);
        Console.WriteLine($"{connection.Name} deleted successfully.");
    }
    catch (ODataError odataError)
    {
        Console.WriteLine($"Error deleting connection: {odataError.ResponseStatusCode}: {odataError.Error?.Code} {odataError.Error?.Message}");
    }
}
async Task RegisterSchemaAsync()
{
    if (currentConnection == null)
    {
        Console.WriteLine("No connection selected. Please create a new connection or select an existing connection.");
        return;
    }

    Console.WriteLine("Registering schema, this may take a moment...");

    try
    {
        // Create the schema
        var schema = new Schema
        {
            BaseType = "microsoft.graph.externalItem",
            //Properties = new List<Property>
            //{
            //    new Property { Name = "partNumber", Type = PropertyType.Int64, IsQueryable = true, IsSearchable = false, IsRetrievable = true, IsRefinable = true },
            //    new Property { Name = "name", Type = PropertyType.String, IsQueryable = true, IsSearchable = true, IsRetrievable = true, IsRefinable = false, Labels = new List<Label?>() { Label.Title }},
            //    new Property { Name = "description", Type = PropertyType.String, IsQueryable = false, IsSearchable = true, IsRetrievable = true, IsRefinable = false },
            //    new Property { Name = "price", Type = PropertyType.Double, IsQueryable = true, IsSearchable = false, IsRetrievable = true, IsRefinable = true },
            //    new Property { Name = "inventory", Type = PropertyType.Int64, IsQueryable = true, IsSearchable = false, IsRetrievable = true, IsRefinable = true },
            //    new Property { Name = "appliances", Type = PropertyType.StringCollection, IsQueryable = true, IsSearchable = true, IsRetrievable = true, IsRefinable = false }
            //},

            Properties = new List<Property>
            {         
                new Property { Name = "filingDate", Type = PropertyType.String, IsQueryable = true, IsSearchable = false, IsRetrievable = true},
                new Property { Name = "reportDate", Type = PropertyType.String, IsQueryable = true, IsSearchable = false, IsRetrievable = true},
                new Property { Name = "companyName", Type = PropertyType.String, IsQueryable = true, IsSearchable = true, IsRetrievable = true},
                new Property { Name = "companyTicker", Type = PropertyType.String, IsQueryable = true, IsSearchable = true, IsRetrievable = true },
                new Property { Name = "cik", Type = PropertyType.String, IsQueryable = true, IsSearchable = true, IsRetrievable = true},
                new Property { Name = "fileNumber",Type = PropertyType.String, IsQueryable = true, IsSearchable = true, IsRetrievable = true},
                new Property { Name = "filmNumber",Type = PropertyType.String, IsQueryable = true, IsSearchable = true, IsRetrievable = true},
                new Property { Name = "formType",Type = PropertyType.String, IsQueryable = true, IsSearchable = true, IsRetrievable = true},
                new Property { Name = "accessionNumber",Type = PropertyType.String, IsQueryable = true, IsSearchable = true, IsRetrievable = true },
                new Property { Name = "filingUrl", Type = PropertyType.String, IsQueryable = true, IsSearchable = true, IsRetrievable = true }
            },
        };

        await GraphHelper.RegisterSchemaAsync(currentConnection.Id, schema);
        Console.WriteLine("Schema registered successfully");
    }
    catch (ServiceException serviceException)
    {
        Console.WriteLine($"Error registering schema: {serviceException.ResponseStatusCode} {serviceException.Message}");
    }
    catch (ODataError odataError)
    {
        Console.WriteLine($"Error registering schema: {odataError.ResponseStatusCode}: {odataError.Error?.Code} {odataError.Error?.Message}");
    }
}

async Task GetSchemaAsync()
{
    if (currentConnection == null)
    {
        Console.WriteLine("No connection selected. Please create a new connection or select an existing connection.");
        return;
    }

    try
    {
        var schema = await GraphHelper.GetSchemaAsync(currentConnection.Id);
        Console.WriteLine(JsonSerializer.Serialize(schema));

    }
    catch (ODataError odataError)
    {
        Console.WriteLine($"Error getting schema: {odataError.ResponseStatusCode}: {odataError.Error?.Code} {odataError.Error?.Message}");
    }
}
async Task UpdateItemsFromDatabaseAsync_old(bool uploadModifiedOnly, string? tenantId)
{
    if (currentConnection == null)
    {
        Console.WriteLine("No connection selected. Please create a new connection or select an existing connection.");
        return;
    }

    _ = tenantId ?? throw new ArgumentException("tenantId is null");

    List<AppliancePart>? partsToUpload = null;
    List<AppliancePart>? partsToDelete = null;

    var newUploadTime = DateTime.UtcNow;

    var partsDb = new ApplianceDbContext();
    partsDb.EnsureDatabase();

    if (uploadModifiedOnly)
    {
        var lastUploadTime = GetLastUploadTime();
        Console.WriteLine($"Uploading changes since last upload at {lastUploadTime.ToLocalTime()}");

        partsToUpload = partsDb.Parts
            .Where(p => EF.Property<DateTime>(p, "LastUpdated") > lastUploadTime)
            .ToList();

        partsToDelete = partsDb.Parts
            .IgnoreQueryFilters()
            .Where(p => EF.Property<bool>(p, "IsDeleted")
                && EF.Property<DateTime>(p, "LastUpdated") > lastUploadTime)
            .ToList();
    }
    else
    {
        partsToUpload = partsDb.Parts.ToList();

        partsToDelete = partsDb.Parts
            .IgnoreQueryFilters()
            .Where(p => EF.Property<bool>(p, "IsDeleted"))
            .ToList();
    }

    Console.WriteLine($"Processing {partsToUpload.Count} add/updates, {partsToDelete.Count} deletes.");
    var success = true;

    foreach (var part in partsToUpload)
    {
        var newItem = new ExternalItem
        {
            Id = part.PartNumber.ToString(),
            Content = new ExternalItemContent
            {
                Type = ExternalItemContentType.Text,
                Value = part.Description
            },
            Acl = new List<Acl>
            {
                new Acl
                {
                    AccessType = AccessType.Grant,
                    Type = AclType.Everyone,
                    Value = tenantId,
                }
            },
            Properties = part.AsExternalItemProperties(),
        };

        try
        {
            Console.Write($"Uploading part number {part.PartNumber}...");
            await GraphHelper.AddOrUpdateItemAsync(currentConnection.Id, newItem);
            Console.WriteLine("DONE");
        }
        catch (ODataError odataError)
        {
            success = false;
            Console.WriteLine("FAILED");
            Console.WriteLine($"Error: {odataError.ResponseStatusCode}: {odataError.Error?.Code} {odataError.Error?.Message}");
        }
    }

    foreach (var part in partsToDelete)
    {
        try
        {
            Console.Write($"Deleting part number {part.PartNumber}...");
            await GraphHelper.DeleteItemAsync(currentConnection.Id, part.PartNumber.ToString());
            Console.WriteLine("DONE");
        }
        catch (ODataError odataError)
        {
            success = false;
            Console.WriteLine("FAILED");
            Console.WriteLine($"Error: {odataError.ResponseStatusCode}: {odataError.Error?.Code} {odataError.Error?.Message}");
        }
    }

    // If no errors, update our last upload time
    if (success)
    {
        SaveLastUploadTime(newUploadTime);
    }
}

async Task UpdateItemsFromDatabaseAsync(bool uploadModifiedOnly, string? tenantId)
{
    var content = Extract();
    var transformed = Transform(content);
    await Load(transformed);
}

async Task LoadDataToSQL()
{
    try
    {
        using (var context = new AppDbContext())
        {
            var companies = context.SecCompanies.ToList();

            var data = await HydrateLookupData(companies).ConfigureAwait(false);

            foreach (var item in data)
            {
                var filingLoad = new SecFiling
                {
                    FilingDate = item.FilingDate,
                    ReportDate = item.ReportDate,
                    FilmNumber = item.FilmNumber,
                    FileNumber = item.FileNumber,
                    CompanyName = item.CompanyName,
                    CompanyTicker = item.CompanyTicker,
                    Cik = item.Cik, // You can still use the Cik to link the company manually, but no foreign key is involved
                    FormType = item.FormType,
                    AccessionNumber = item.AccessionNumber,
                    FilingUrl = item.FilingUrl
                };

                context.SecFilings.Add(filingLoad);
                context.SaveChanges(); // Save the filing
            }


            //// Create and add a new company
            //var company = new SecCompany
            //{
            //    Cik = "0000320193",
            //    Name = "Apple Inc.",
            //    Ticker = "AAPL",
            //    Description = "Apple Inc. designs, manufactures, and markets consumer electronics and software."
            //};

            //context.SecCompanies.Add(company);
            //context.SaveChanges(); // Save the company first

            //Console.WriteLine("Company added!");

            //// Create and add a new filing
            //var filing = new SecFiling
            //{
            //    FilingDate = DateTime.Now,
            //    CompanyName = "Apple Inc.",
            //    Cik = company.Cik, // You can still use the Cik to link the company manually, but no foreign key is involved
            //    FormType = "10-K",
            //    AccessionNumber = "0000320193-22-000012",
            //    FilingUrl = "https://www.sec.gov/Archives/edgar/data/320193/000032019322000012/aapl-20211225.htm"
            //};

            //context.SecFilings.Add(filing);
            //context.SaveChanges(); // Save the filing

            //Console.WriteLine("Filing added!");

            //// Retrieve and display all companies
            //var companiesLoad = context.SecCompanies.ToList();
            //foreach (var secCompany in companiesLoad)
            //{
            //    Console.WriteLine($"Company: {secCompany.Name} ({secCompany.Ticker})");
            //}

            //// Retrieve and display all filings
            //var filings = context.SecFilings.ToList();
            //foreach (var secFiling in filings)
            //{
            //    Console.WriteLine($"Filing: {secFiling.FormType} | Date: {secFiling.FilingDate} | Accession: {secFiling.AccessionNumber}");
            //}


        }
    }
    catch (Exception ex)
    {
        throw ex;
    }
}
async Task<List<SecFiling>> HydrateLookupData(List<SecCompany> companies)
{
    string url = "https://www.sec.gov/files/company_tickers.json";

    HttpClient _client = new HttpClient();
    _client.DefaultRequestHeaders.Add("User-Agent", "(PNC vinod.dhanwe542@pnc.com)");    
    var company_tkr_response = await _client.GetStringAsync(url).ConfigureAwait(false);

    try
    {

        foreach (var entity in companies)
        {
            string companyName = entity.Name;
            string companySymbol = entity.Ticker;
            string cikLookup = entity.Cik;

            string filingJson = await GetCIKFiling(cikLookup).ConfigureAwait(false);
            var  docs = await GetDocument(filingJson, entity).ConfigureAwait(false);
            if (docs != null)
            {
                filingDocuments.AddRange(docs);
            }
        }
    }
    catch (Exception ex)
    {
       
    }

    return filingDocuments;
}

// Define a method to extract CIK from JSON response
static string ExtractCIK(string json, SecCompany secComp)
{
    var jsonObject = JsonDocument.Parse(json).RootElement;
    foreach (var item in jsonObject.EnumerateObject())
    {
        var company = item.Value;
        if (company.GetProperty("ticker").GetString().Trim().Equals(secComp.Ticker, StringComparison.OrdinalIgnoreCase))
        {
            return company.GetProperty("cik_str").ToString();
        }
    }
    return "Company not found";
}

// Define an asynchronous static method to get CIK filing
async static Task<string> GetCIKFiling(string cikLookup)
{
    if (string.IsNullOrEmpty(cikLookup))
    {
        return "";
    }
    string cik = cikLookup;
    cikLookup = cikLookup.PadLeft(10, '0');

    HttpClient _client = new HttpClient();
    _client.DefaultRequestHeaders.Add("User-Agent", "(PNC vinod.dhanwe542@pnc.com)");
    var filingString = await _client.GetStringAsync($"https://data.sec.gov/submissions/CIK{cikLookup}.json").ConfigureAwait(false);

    return filingString;
}

// Define an asynchronous static method to get document from filing string
async static Task<List<SecFiling>> GetDocument(string filingString, SecCompany secComp)
{
    string retVal = "";

    string cik = secComp.Cik;
    cik = cik.PadLeft(10, '0');

    List<SecFiling> externalItemData = new List<SecFiling>();
    using (JsonDocument doc = JsonDocument.Parse(filingString))
    {
        JsonElement root = doc.RootElement;

        // Access the "filings" element
        JsonElement filings = root.GetProperty("filings");
        var compName = root.GetProperty("name").GetString();
        
        // Access the "recent" element within "filings"
        JsonElement recentFilings = filings.GetProperty("recent");

        var aNumberObj = recentFilings.GetProperty("accessionNumber");
        var formsObj = recentFilings.GetProperty("form");
        var pDocObj = recentFilings.GetProperty("primaryDocument");
        var reportDateObj = recentFilings.GetProperty("reportDate");
        var filingDateObj = recentFilings.GetProperty("filingDate");
        var fileNumberObj = recentFilings.GetProperty("fileNumber");
        var filmNumberObj = recentFilings.GetProperty("filmNumber");

        // Iterate through the recent filings
        for (int i = 0; i < formsObj.GetArrayLength(); i++)
        {
            try
            {
                if (reportDateObj[i].ToString().Length < 10)
                {
                    continue;
                }
                var reportDate = DateTime.Parse(reportDateObj[i].ToString());
                int yearsOfData = 0;
                //Int32.TryParse(Environment.GetEnvironmentVariable("YearsOfData"), out yearsOfData);

                if (yearsOfData == 0)
                {
                    yearsOfData = -5;
                }

                // Check if the date is more than 2 years in the past
                if (reportDate < DateTime.Now.AddYears(yearsOfData))
                {
                    continue;
                }

                var form = formsObj[i].ToString();
                var aNumber = aNumberObj[i].ToString();
                var pDoc = pDocObj[i].ToString();
                aNumber = aNumber.Replace("-", "");

                string filingDate = filingDateObj[i].ToString();
                string fileNumber = fileNumberObj[i].ToString();
                string filmNumber = filmNumberObj[i].ToString();

                // Populate data for Schema population
                string urlField = $"https://www.sec.gov/Archives/edgar/data/{cik}/{aNumber}/{pDoc}";

                // Insert Azure Table bookkeeping to know which documents are available and which documents I've gathered
                // Want to log all data available, and only update data that I have gathered
                try
                {
                    //if (form.ToUpper().Contains("10-K") || form.ToUpper().Contains("10-Q") || form.ToUpper().Contains("8-K")
                    //    || form.ToUpper().Contains("DEF 14A") || form.ToUpper().Contains("DEFA14A") 
                    //    || form.ToUpper().Contains("S-8") || form.ToUpper().Contains("S-8 POS") || form.ToUpper().Contains("S-8/A")
                    //    || form.ToUpper().Contains("FORM 4"))

                    if (form.Contains("10-K", StringComparison.CurrentCultureIgnoreCase) || form.Contains("10-Q", StringComparison.CurrentCultureIgnoreCase) 
                        || form.Contains("8-K", StringComparison.CurrentCultureIgnoreCase) || form.Contains("DEFA14A", StringComparison.CurrentCultureIgnoreCase))
                    {
                        var test1 = formsObj[i];

                        // SecFiling edgarExternalItem = new SecFiling(theDate, secComp.Ticker, cik, form, aNumber, urlField);\
                        SecFiling edgarExternalItem = new SecFiling
                        {
                            // Required properties
                            ReportDate = reportDate,
                            FilingDate = DateTime.Parse(filingDateObj[i].ToString()),
                            CompanyTicker = secComp.Ticker,
                            CompanyName = compName,
                            Cik = cik, // Must match the foreign key format
                            FormType = form,
                            AccessionNumber = aNumber,
                            FilingUrl = urlField,
                            FileNumber = fileNumber,
                            FilmNumber = filmNumber,
                            //Name= compName.ValueKind,
                            // Optional properties (if not using defaults)
                            IsSynced = false,
                            CreatedAt = DateTime.UtcNow // Already defaults to UtcNow, so optional
                        };
                        externalItemData.Add(edgarExternalItem);
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    
    }
    return externalItemData;
}

static IEnumerable<DocsFiling> Extract()
{
    var docs = new List<DocsFiling>();

    using (var context = new AppDbContext())
    {
        var filings = context.SecFilings.ToList();

        foreach (var item in filings)
        {
            HttpClient _client = new HttpClient();
            _client.DefaultRequestHeaders.Add("User-Agent", "(PNC vinod.dhanwe542@pnc.com)");
            var company_tkr_response = _client.GetStringAsync(item.FilingUrl).ConfigureAwait(false).GetAwaiter().GetResult();

            try
            {
                var contents = company_tkr_response;
                var doc = contents.GetContents<DocsFiling>();
                doc.Content = Markdown.ToHtml(doc.Markdown ?? "");
                doc.FilingDate = item.FilingDate;
                doc.ReportDate = item.ReportDate;
                doc.Cik = item.Cik;
                doc.FormType = item.FormType;
                doc.CompanyName = item.CompanyName;
                doc.CompanyTicker = item.CompanyTicker;
                doc.FileNumber =   item.FileNumber;
                doc.FilmNumber= item.FilmNumber;
                doc.AccessionNumber = item.AccessionNumber;
                doc.FilingUrl = item.FilingUrl;
                // doc.RelativePath = Path.GetRelativePath(contentFolderPath, file);
                docs.Add(doc);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }

       

    return docs;
}

static IEnumerable<ExternalItem> Transform(IEnumerable<DocsFiling> content)
{
    var baseUrl = new Uri("https://learn.microsoft.com/graph/");

    return content.Select(a =>
    {
        var docId = a.CompanyTicker + "_" +  a.AccessionNumber ;
        return new ExternalItem
        {
            Id = docId,
            Properties = new()
            {
                AdditionalData = new Dictionary<string, object> {
                    { "filingDate", a.FilingDate.ToString("yyyy-MM-dd")  },
                    { "reportDate", a.ReportDate.ToString("yyyy-MM-dd")  },
                    { "companyName", a.CompanyName ?? "" },
                    { "companyTicker", a.CompanyTicker ?? "" },
                    { "cik", a.Cik ?? "" },
                    { "fileNumber", a.FileNumber?? "" },
                    { "filmNumber", a.FilmNumber ?? ""},
                    { "formType", a.FormType ?? "" },
                    { "accessionNumber", a.AccessionNumber ?? "" },
                    { "filingUrl", a.FilingUrl }
                }
            },
            Content = new()
            {
                Value = a.Markdown.Replace("\r\n", string.Empty).Replace("\n",string.Empty),
                Type = ExternalItemContentType.Html
            },
            Acl = new()
            {
                new ()
                {
                   Type = AclType.Everyone,
                   Value = "everyone",
                   AccessType = AccessType.Grant
                }
            }
        };
    });

    //var newItem1 = new ExternalItem();

    //foreach (var doc in content)
    //{
    //    var newItem = new ExternalItem
    //    {
    //        Id = "0000096223_t8_K_t000095015723000715",
    //        Content = new ExternalItemContent
    //        {
    //            Type = ExternalItemContentType.Html,
    //            Value = doc.Content
    //        },
    //        Acl = new List<Acl>
    //        {
    //            new Acl
    //            {
    //                AccessType = AccessType.Grant,
    //                Type = AclType.Everyone,
    //                Value = "b13b520a-81cd-406c-99f4-b8661531e0f7",
    //            }
    //        },
    //        Properties = new()
    //        {
    //            AdditionalData = new Dictionary<string, object> {

    //                    { "filingDate", doc.FilingDate  },
    //                    { "formType", doc.FormType  },
    //                    { "cik", doc.Cik ?? "" },
    //                    { "companyName", doc.CompanyName ?? "" },
    //                    { "accessionNumber", doc.AccessionNumber ?? "" },
    //                    { "filingUrl", new Uri(doc.FilingUrl) }
    //                }
    //        }
    //        };

    //    newItem1 = newItem;
    //}

    //return newItem1;

}

static async Task Load(IEnumerable<ExternalItem> items)
{
    foreach (var item in items)
    {
        Console.Write(string.Format("Loading item {0}...", item.Id));
        try
        {
            await GraphHelper.AddOrUpdateItemAsync("SECDataSource", item);

            Console.WriteLine("DONE");
        }
        catch (Exception ex)
        {
            Console.WriteLine("ERROR");
            Console.WriteLine(ex.Message);
        }
    }
}