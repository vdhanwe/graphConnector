﻿using Graph_PartsInventoryConnector.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Graph_PartsInventoryConnector
{
    public class AppDbContext : DbContext
    {
        public DbSet<SecCompany> SecCompanies { get; set; }
        public DbSet<SecFiling> SecFilings { get; set; }

        // Replace the connection string as needed
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=localhost,1433;Initial Catalog=Custom_DB;User id=sa;Password=Pass@123$;TrustServerCertificate=True;");
        }
    }
}
